Fordham Engagement System.

Main focus is to add and maintain student organizations and student database on the platform. Here you can add and view and organization and also a singular student to the database to keep records for differnt organizations.

Login:

ID: shreya.annika@gmamil.com
Pass: Shreyapatel