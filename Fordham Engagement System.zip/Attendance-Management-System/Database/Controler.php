<?php
session_start();
include 'Model.php';
$md = new model();

date_default_timezone_set('America/New_York');

$a_y = $md->display($con, "academic_year");
$fd = date("Y");
$a_yf = $md->sel_pattern($con, "academic_year", "ac_year", $fd . "%");
$crs = $md->display($con, "course");

//Login
if (isset($_REQUEST["login"])) {
    $where = array(
        "email" => $_REQUEST["unm"],
        "password" => $_REQUEST["pwd"],
    );

    $d = $md->login($con, "faculty", $where);
    $fac_data = $d->fetch_object();
    //Fatch faculty data
    $where = array(
        "fac_id" => $fac_data->fac_id
    );
    $_SESSION["ufac_id"] = $fac_data->ufac_id;
    $_SESSION["fac_name"] = $fac_data->fac_name;
    $_SESSION["role"] = $fac_data->role;

    //Fatch course data
    $where = array(
        "c_id" => $fac_data->c_id
    );
    $main_data = array(
        "fac_data" => $fac_data,
    );

    $_SESSION["d"] = $main_data;

    header("location:dashboard.php");
}
//Logout
if (isset($_REQUEST["logout"])) {
    session_destroy();
    header("location:index.php");
}

//Student Department
//Student Registration
if (isset($_REQUEST["R_organizationmit"])) {
    $fn = $_REQUEST["firstname"];
    $ln = $_REQUEST["lastname"];
    $s_rn = $_REQUEST["s_rn"];
    $sem = $_REQUEST["semr"];
    $gen = $_REQUEST["s_gen"];
    $email = $_REQUEST["email"];
    $cn = $_REQUEST["cn"];
    $c_id = $_REQUEST["c_idr"];
    $div = $_REQUEST["division"];

    $data = array("s_rn" => $s_rn, "fnm" => $fn, "lnm" => $ln, "s_gen" => $gen, "email" => $email, "contact" => $cn,
        "c_id" => $c_id, "sem" => $sem, "division" => $div);
    //print_r($data);exit;
    $md->insert($con, $data, "student");
}
//View Student req
if (isset($_REQUEST["view_stu"])) {
    $year = $_REQUEST["c_id"];
    $sem = $_REQUEST["semester"];
    $div = strtolower($_REQUEST["division"]);
    $where = array(
        "c_id" => $year,
        "sem" => $sem,
        "division" => $div
    );
    $div_res = $md->sel_where($con, "student", $where);
    $_SESSION["sl"] = $div_res;
    header("location:stu_list.php");
}
//View more
if (isset($_REQUEST["s_enrlvm"])) {
    $s_enrl = $_REQUEST["s_enrlvm"];
    $where = array(
        "s_enrl" => $s_enrl
    );
    $data = $md->sel_where($con, "student", $where);
    $data1 = serialize($data);
    header("location:view_more.php?d1=$data1");
}
//Student update req
if (isset($_REQUEST["s_enrlup"])) {
    $s_enrl = $_GET["s_enrlup"];
    $where = array(
        "s_enrl" => $s_enrl
    );
    $data = $md->sel_where($con, "student", $where);
    $d1 = serialize($data);
    header("location:stu_update.php?d1=$d1");
}
//Student update
if (isset($_REQUEST["stu_update"])) {
    $en = $_REQUEST["s_enrl"];
    $fn = $_REQUEST["firstname"];
    //$ln=$_REQUEST["lastname"];
    $s_rn = $_REQUEST["s_rn"];
    $email = $_REQUEST["email"];
    $cn = $_REQUEST["cn"];
    $sem = $_REQUEST["sem"];
    $div = $_REQUEST["division"];

    $data = array("s_rn" => $s_rn, "fnm" => $fn, "email" => $email, "contact" => $cn, "sem" => $sem, "division" => $div);
    //print_r($data);exit;
    $where = array(
        "s_enrl" => $en
    );
    $md->updt($con, $data, "student", $where);
    $where = array(
        "c_id" => $_REQUEST["c_id"],
        "sem" => $_REQUEST["osem"],
        "division" => $_REQUEST["div"]
    );
    $div_res = $md->sel_where($con, "student", $where);
    $_SESSION["sl"] = $div_res;
    header("location:stu_list.php");
}
//Student Delete
if (isset($_REQUEST["s_enrldel"])) {
    $s_enrl = $_REQUEST["s_enrldel"];
    $where = array(
        "s_enrl" => $s_enrl
    );
    $stdata = $md->sel_where($con, "student", $where);
    $md->delete1($con, "student", $where);
    foreach ($stdata as $sd) {
        $where = array(
            "c_id" => $sd->c_id,
            "sem" => $sd->sem,
            "division" => $sd->division
        );
    }
    $div_res = $md->sel_where($con, "student", $where);
    $_SESSION["sl"] = $div_res;
    header("location:stu_list.php");
}
//organizationject Department
//Add organizationject
//1. If MBA and Special organizationject then fetch specialization
if (isset($_REQUEST["add_spec_organization"])) {
    $l = explode(" ", $_REQUEST["add_spec_organization"]);
    $where = array(
        "c_id" => 1,
        "special" => 1,
        "sem_no" => $l[2]
    );
    $spec = $md->sel_where($con, "organizationject", $where);
}
//2. Add organizationject in databse
if (isset($_REQUEST["organization_organizationmit"])) {
    $cr = $_REQUEST["cr"];
    $sp = $_REQUEST["sp"];
    if ($cr == 1 && $sp == 1) {
        $as = $_REQUEST["as1"];
        $data = array("uorganization_id" => $as, "organization_id" => $_REQUEST["sid"], "organization_name" => $_REQUEST["organizationnm"],
            "sem_no" => $_REQUEST["sem"], "ufac_id" => 0);
        //print_r($data);exit;
        $md->insert($con, $data, "organizationject1");
        $organization_data = $md->dis_join_con1($con, "organizationject", "faculty", "organizationject.ufac_id=faculty.ufac_id", $where);
        $_SESSION["organizationdata"] = $organization_data;
        header("location:view_organization.php");
    } else {
        $data = array("organization_id" => $_REQUEST["sid"], "organization_name" => $_REQUEST["organizationnm"], "c_id" => $_REQUEST["cr"],
            "special" => $_REQUEST["sp"], "organization_type" => $_REQUEST["type"], "sem_no" => $_REQUEST["sem"], "ufac_id" => 0);
        $md->insert($con, $data, "organizationject");
        $organization_data = $md->dis_join_con1($con, "organizationject", "faculty", "organizationject.ufac_id=faculty.ufac_id", $where);
        $_SESSION["organizationdata"] = $organization_data;
        header("location:view_organization.php");
    }
}
//Distribute organizationject req
if (isset($_REQUEST["prt_organization"])) {
    $ex = rtrim($_REQUEST["prt_organization"], " ue");
    if ($ex == $_REQUEST["prt_organization"]) {
        $where = array("uorganization_id" => $_REQUEST["prt_organization"]);
        //$prt_organization=$md->sel_pattern_not($con,"organizationject", $where,"organization_id","_%");
        $prt_organization = $md->sel_where($con, "organizationject", $where);
        $_SESSION["ptid"] = $_REQUEST["prt_organization"];
        if ($_SESSION["partd"] == 2) {
            foreach ($prt_organization as $ps) {
                $_SESSION["ptsem"] = $ps->sem_no;
                $_SESSION["ptsid1"] = $ps->organization_id . " x%";
                $_SESSION["ptsid2"] = $ps->organization_id . " y%";
                $_SESSION["ptsp"] = $ps->special;
                $_SESSION["ptst"] = $ps->organization_type;
                $_SESSION["ptc_id"] = $ps->c_id;
                $_SESSION["ptsnm"] = $ps->organization_name;
            }
        } else {
            foreach ($prt_organization as $ps) {
                $_SESSION["ptsem"] = $ps->sem_no;
                $_SESSION["ptsid1"] = $ps->organization_id . " x%";
                $_SESSION["ptsid2"] = $ps->organization_id . " y%";
                $_SESSION["ptsid3"] = $ps->organization_id . " z%";
                $_SESSION["ptsp"] = $ps->special;
                $_SESSION["ptst"] = $ps->organization_type;
                $_SESSION["ptc_id"] = $ps->c_id;
                $_SESSION["ptsnm"] = $ps->organization_name;
            }
        }
    } else {
        $where = array("ueorganization_id" => $_REQUEST["prt_organization"]);
        $prt_organization = $md->sel_where($con, "organizationject1", $where);
        $_SESSION["ptid"] = $_REQUEST["prt_organization"];
        if ($_SESSION["partd"] == 2) {
            foreach ($prt_organization as $ps) {
                $_SESSION["ptuorganization"] = $ps->uorganization_id;
                $_SESSION["ptsem"] = $ps->sem_no;
                $_SESSION["ptsid1"] = $ps->organization_id . " x%";
                $_SESSION["ptsid2"] = $ps->organization_id . " y%";
                $_SESSION["ptsnm"] = $ps->organization_name;
            }
        } else {
            foreach ($prt_organization as $ps) {
                $_SESSION["ptuorganization"] = $ps->uorganization_id;
                $_SESSION["ptsem"] = $ps->sem_no;
                $_SESSION["ptsid1"] = $ps->organization_id . " x%";
                $_SESSION["ptsid2"] = $ps->organization_id . " y%";
                $_SESSION["ptsid3"] = $ps->organization_id . " z%";
                $_SESSION["ptsnm"] = $ps->organization_name;
            }
        }
    }
}
//Distribute organizationject
if (isset($_REQUEST["prt_organizationmit"])) {
    $ex = rtrim($_REQUEST["organizationject"], " ue");
    if ($ex != $_REQUEST["organizationject"]) {
        $data = array(
            "organization_name" => $_SESSION["ptsnm"] . " x%",
            "organization_id" => $_SESSION["ptsid1"],
            "ufac_id" => $_REQUEST["fac1"]
        );
        $where = array(
            "ueorganization_id" => $_SESSION["ptid"]
        );
        $md->updt($con, $data, "organizationject1", $where);
        $data = array(
            "uorganization_id" => $_SESSION["ptuorganization"],
            "organization_name" => $_SESSION["ptsnm"] . " y%",
            "organization_id" => $_SESSION["ptsid2"],
            "ufac_id" => $_REQUEST["fac2"],
            "sem_no" => $_SESSION["ptsem"]
        );
        $md->insert($con, $data, "organizationject1");

        if ($_SESSION["partd"] == 3) {
            $data = array(
                "uorganization_id" => $_SESSION["ptuorganization"],
                "organization_name" => $_SESSION["ptsnm"] . " z%",
                "organization_id" => $_SESSION["ptsid3"],
                "ufac_id" => $_REQUEST["fac3"],
                "sem_no" => $_SESSION["ptsem"]
            );
            $md->insert($con, $data, "organizationject1");
        }
        $where = array("1" => 1);
        $organization_data = $md->dis_join_con1($con, "organizationject1", "faculty", "organizationject1.ufac_id=faculty.ufac_id", $where);
        $_SESSION["organizationdata"] = $organization_data;
        header("location:view_organization.php");
    } else {
        $data = array(
            "organization_name" => $_SESSION["ptsnm"] . " x%",
            "organization_id" => $_SESSION["ptsid1"],
            "ufac_id" => $_REQUEST["fac1"]
        );
        $where = array(
            "uorganization_id" => $_SESSION["ptid"]
        );
        $md->updt($con, $data, "organizationject", $where);
        $data = array(
            "organization_name" => $_SESSION["ptsnm"] . " y%",
            "organization_id" => $_SESSION["ptsid2"],
            "ufac_id" => $_REQUEST["fac2"],
            "special" => $_SESSION["ptsp"],
            "organization_type" => $_SESSION["ptst"],
            "sem_no" => $_SESSION["ptsem"],
            "c_id" => $_SESSION["ptc_id"]
        );
        $md->insert($con, $data, "organizationject");
        if ($_SESSION["partd"] == 3) {
            $data = array(
                "organization_name" => $_SESSION["ptsnm"] . " z%",
                "organization_id" => $_SESSION["ptsid3"],
                "ufac_id" => $_REQUEST["fac3"],
                "special" => $_SESSION["ptsp"],
                "organization_type" => $_SESSION["ptst"],
                "sem_no" => $_SESSION["ptsem"],
                "c_id" => $_SESSION["ptc_id"]
            );
            $md->insert($con, $data, "organizationject");
        }
        $where = array("1" => 1);
        $organization_data = $md->dis_join_con1($con, "organizationject", "faculty", "organizationject.ufac_id=faculty.ufac_id", $where);
        $_SESSION["organizationdata"] = $organization_data;
        header("location:view_organization.php");
    }
}

//Assign Special organizationject
if (isset($_REQUEST["crs_spec"])) {
    $strm1 = $_REQUEST["crs_spec"];
    $strm = explode(" ", $strm1);
    if ($strm[0] == 0) {
        $where = array(
            "c_id" => $strm[0],
            "special" => "1"
        );
        $spec_res = $md->sel_where($con, "organizationject", $where);
        $_SESSION["spec_res"] = $spec_res;
    } else {
        $where = array(
            "organizationject.sem_no" => "9"
        );
        $clm = "DISTINCT organizationject1.uorganization_id,organizationJECT.organization_name,organizationject.sem_no";
        $str = "organizationject1.uorganization_id = organizationJECT.uorganization_id";
        $spec_res = $md->dis_join_con($con, "organizationject", "organizationject1", $str, $where, $clm);
        $_SESSION["spec_res"] = $spec_res;
    }
    if ($strm[0] == 0) {
        $where = array(
            "sem" => '6',
            "c_id" => '0',
            "division" => $strm[1]
        );
        $ass_stu = $md->sel_where($con, "student", $where);
        $_SESSION["ass_stu"] = $ass_stu;
    } else {
        $where = array(
            "sem" => '9',
            "c_id" => '1',
            "division" => $strm[1]
        );
        $ass_stu = $md->sel_where($con, "student", $where);
        $_SESSION["ass_stu"] = $ass_stu;
    }
}
//Assign Special organizationject to student
if (isset($_REQUEST["ass_organization_organizationmit"])) {
    $total = $_REQUEST["total"];

    for ($c = 1; $c <= $total; $c++) {
        $si = 0;
        foreach ($_SESSION["spec_res"] as $s) {
            $si++;
            if (isset($_REQUEST["ch$si$c"])) {
                $where = array(
                    "s_enrl" => $_REQUEST["sp$c"]
                );
                $data = array(
                    "uorganization_id" => $s->uorganization_id
                );
                $asf = $md->updt($con, $data, "student", $where);
            }
        }
    }
}

//View Organization
if (isset($_REQUEST["vs"])) 
{
    $where = array(1 => '1');
    $organizationc_data = $md->dis_join_con1($con, "Organization", $where);
    $organizatione_data = $md->dis_join_con1($con, "Organization1", $where);
    $organization_data = array_merge($organizationc_data, $organizatione_data);
  
    $secondArray = $secondArray ?? []; 
    $result = array_merge($firstArray, $secondArray);

    $_SESSION["organizationdata"] = $organization_data;

    header("location:view_organization.php");
}
//Assign Organization
if (isset($_REQUEST["crs_fac"])) {
    $where = array($_REQUEST["crs_fac"], 2);
    $organization_fac = $md->sel_where_or($con, "faculty", $where, "c_id");
}
if (isset($_REQUEST["crs_Organization"])) {
    $where = array(
        "c_id" => $_REQUEST["crs_Organization"]
    );
    $organization_organization = $md->sel_where($con, "Organization", $where);
    $organizatione_organization = $md->sel_all($con, "Organization1");
}





  


?>