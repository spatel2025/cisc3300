<?php
    include './Database/Controler.php';
    include 'role.php';
?>
<script language="javascript" type="text/javascript">
        
function getYear(crs)
{
	var crs=crs;
                   if(crs)
                   {
                            $.ajax({
                                                type:"GET",
                                                url:"dropdown.php",
                                                data:"crs="+crs,
                                                success:function(result)
                                                {
                                                          $("#year").html(result);
                                                }
                                      });
                   }
}
function getSemester(yr)
{
	var yr=yr;
                   if(yr)
                   {
                             $.ajax({
                                                type: "GET",
                                                url:"dropdown.php",
                                                data:"yr="+yr,
                                                success:function(result)
                                                {
			$("#semester").html(result);
                                                }
		});
                           
                  
}
</script>
<script language="javascript" src="./assets/js/validation.js"></script>
<script language="javascript">
function validate_form(f1)
  {
       
       if(isEmpty(f1.year.value,"the Year"))
      {
        alert(errMsg);
        f1.year.focus();
        return (false);
      }
      
  
      
      
 }
  </script>
  </script>
   <?php
  if($_SESSION["role"]==1)
  {
  ?>
<h2>View Student List</h2> 
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-body">
<div class="table-responsive">

<form method="post" onSubmit="return validate_form(this)">
<table class="table table-striped table-bordered table-hover" id="dataTables-example">
<thead>
    
        <td><b>Select Year :</b>
               <div class="form-group">
                                            
                                            <select class="form-control" id="semr" name="semr" style="">
                                     <option value="">Select Year</option>
                                    <option value="1">Freshman</option>
                                    <option value="2">Sophomore</option>
                                    <option value="3">Junior</option>
                                    <option value="4">Senior</option>
                                    
                                            </select>
                                        </div>
               </td>
               
    </tr>
  
     </thead>
     <tr>
         <td colspan="2"><center>
                 <button type="submit" id="view_stu" name="view_stu" class="btn btn-primary"style="width: 30%;" >View Students</button>
                 </center> </td>
    </tr> 
                 </table>
    </form>
    </div>
    </div>
    </div>
   </div>
   </div>
   </div>
   </div>
   </div>

<?php
}
 else {
     ?>
<div class="row">
    <div class="col-md-12"></div>
    <img src="img/ad.jpg">
    <?php
    
 }
    include 'footer.php';
?>