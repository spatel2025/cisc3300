<?php
        include './Database/Controler.php';
        include 'role.php';
?>
          
                 <!-- /. ROW  -->
<script language="javascript" src="./assets/js/validation.js"></script>
<script language="javascript">
function num_check(event)
    {
       code=event.keyCode
       if(!((code>=48 && code<=57)))
      {
         alert("Please Enter Only Numbers"); 
         event.keyCode=0; 
      } 
    }
function validate_form(f1)
  {
      if(isEmpty(f1.firstname.value,"the First Name.."))
      {
        alert(errMsg);
        f1.firstname.focus();
        return (false);
      }
      if(isEmpty(f1.lastname.value,"the Last Name.."))
      {
        alert(errMsg);
        f1.lastname.focus();
        return (false);
      }
      
      
      if(isEmpty(f1.semr.value,"the Semester.."))
      {
        alert(errMsg);
        f1.semr.focus();
        return (false);
      }
         if(isEmpty(f1.email.value,"the Email Id.."))
      {
        alert(errMsg);
        f1.email.focus();
        return (false);
      }
       if(isEmpty(f1.contact.value,"the Contact Number.."))
      {
        alert(errMsg);
        f1.contact.focus();
        return (false);
      }
     
     
  }
</script>                 
  <?php
  if($_SESSION["role"]==1)
  {
  ?>              
  <h2>Student Registration</h2>   
                        
                       
                    </div>
                </div>
                 <!-- /. ROW  -->
                 
                  <div class="row">
                <div class="col-md-12">
<div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <form method="post" role="form" enctype="multipart/form-data" onSubmit="return validate_form(this)">
                                    
                                        <div class="form-group">
                                            <label>First Name:</label>
                                            <input class="form-control" id="firstname" name="firstname" placeholder="Enter First Name"/>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Last Name:</label>
                                            <input class="form-control" id="lastname" name="lastname" placeholder="Enter Last Name" />
                                        </div>
                                        
                                        
                                       <div class="form-group">
                                            <label>Gender:</label>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" id="s_gen" name="s_gen" value="0"/>Male
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label>
                                                    <input type="radio" id="s_gen" name="s_gen" value="1"/>Female
                                                </label>
                                            </div>
                                            
                                        </div>
                                       <div class="form-group">
                                            <label>Email Id :</label>
                                            <input class="form-control" id="email" name="email" placeholder="Enter Email Id" pattern="^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$"/>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Contact Number. :</label>
                                            <input class="form-control" id="cn" name="cn" maxlength="10" placeholder="Enter Contact Number" onKeyPress="num_check(event)"/>
                                            
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Select Year:</label>
                                            <select class="form-control" id="semr" name="semr" style="">
                                     <option value="">Select Year</option>
                                    <option value="1">Freshman</option>
                                    <option value="2">Sophomore</option>
                                    <option value="3">Junior</option>
                                    <option value="4">Senior</option>
                                    
                                            </select>
                                        </div>
                                       
                
                                        <center>
                          <button type="submit" id="submit" name="R_submit" value="Register" class="btn btn-primary" >Register</button>
                         
                                        </center>
                      </form>
                            
                            
      
      
</center>
<?php
  }
 else {
     ?>
<div class="row">
    <div class="col-md-12"></div>
    <img src="img/ad.jpg">
    <?php
    
 }
    include 'footer.php';
?>

